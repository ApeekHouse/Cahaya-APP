using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using System;
using System.IO;
using System.Linq;
using System.Diagnostics;
using System.Threading;
using System.Reflection;

namespace AluGlassApp.App
{
    internal class Program
    {
        // Initialization code. Don't use any Avalonia, third-party APIs or any
        // SynchronizationContext-reliant code before AppMain is called: things aren't initialized
        // yet and stuff might break.
        [STAThread]
        public static void Main(string[] args)
        {
            // Set the working directory to the application location
            try {
                Directory.SetCurrentDirectory(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            } catch {
                // Ignore errors, we'll continue with current directory
            }
            
            try
            {
                // Check if we're running on Replit
                if (IsReplitEnvironment())
                {
                    // We're on Replit, just show info and exit
                    System.Console.WriteLine("======================================================");
                    System.Console.WriteLine("AluGlass Estimator - Aplikasi Desktop Windows");
                    System.Console.WriteLine("======================================================");
                    System.Console.WriteLine("Aplikasi ini adalah aplikasi desktop yang dirancang untuk Windows.");
                    System.Console.WriteLine("Anda tidak dapat menjalankannya langsung di Replit.");
                    System.Console.WriteLine("Silakan lihat CARA_UNDUH.md untuk instruksi lengkap.");
                    System.Console.WriteLine("======================================================");
                    return;
                }
                
                // Check for required DLLs on Windows
                if (IsWindowsEnvironment() && !AreRequiredDllsPresent())
                {
                    ShowErrorMessage(
                        "File DLL yang diperlukan tidak ditemukan.\n\n" +
                        "Pastikan semua file berikut berada di folder yang sama dengan executable:\n" +
                        "- av_libglesv2.dll\n" +
                        "- e_sqlite3.dll\n" +
                        "- libHarfBuzzSharp.dll\n" +
                        "- libSkiaSharp.dll\n\n" +
                        "Coba ekstrak ulang file AluGlassEstimator_v2.zip ke folder kosong."
                    );
                    
                    System.Console.Error.WriteLine("ERROR: File DLL yang diperlukan tidak ditemukan.");
                    System.Console.Error.WriteLine("Pastikan semua file berikut berada di folder yang sama dengan executable:");
                    System.Console.Error.WriteLine("- av_libglesv2.dll");
                    System.Console.Error.WriteLine("- e_sqlite3.dll");
                    System.Console.Error.WriteLine("- libHarfBuzzSharp.dll");
                    System.Console.Error.WriteLine("- libSkiaSharp.dll");
                    return;
                }
                
                // Check for necessary access rights
                if (!HasWriteAccessToAppFolder())
                {
                    ShowErrorMessage(
                        "Aplikasi memerlukan akses tulis ke folder aplikasi.\n\n" +
                        "Coba salah satu dari tindakan berikut:\n" +
                        "1. Jalankan aplikasi sebagai Administrator (klik kanan -> Run as administrator)\n" +
                        "2. Pindahkan aplikasi ke folder yang memiliki akses penuh (misal: Documents)\n" +
                        "3. Pastikan folder aplikasi tidak dalam mode read-only"
                    );
                    
                    System.Console.Error.WriteLine("ERROR: Tidak memiliki akses tulis ke folder aplikasi.");
                    return;
                }
                
                // Ensure data directories exist
                EnsureDataDirectoriesExist();
                
                // We're on Windows or other supported platform, proceed normally
                BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
            }
            catch (Exception ex)
            {
                // Log exception details to a file for troubleshooting
                try
                {
                    string logDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AluGlassEstimator", "Logs");
                    Directory.CreateDirectory(logDir);
                    string logFile = Path.Combine(logDir, $"error_{DateTime.Now:yyyyMMdd_HHmmss}.log");
                    File.WriteAllText(logFile, $"Error Time: {DateTime.Now}\nError Message: {ex.Message}\nStack Trace: {ex.StackTrace}");
                    
                    ShowErrorMessage(
                        $"Aplikasi mengalami kesalahan: {ex.Message}\n\n" +
                        $"Detail kesalahan telah disimpan di:\n{logFile}\n\n" +
                        "Silakan coba jalankan aplikasi kembali atau hubungi dukungan teknis."
                    );
                }
                catch
                {
                    // If we can't even log the error, show a simple message
                    ShowErrorMessage(
                        $"Aplikasi mengalami kesalahan yang tidak terduga: {ex.Message}\n\n" +
                        "Silakan coba jalankan aplikasi kembali atau hubungi dukungan teknis."
                    );
                }
                
                System.Console.Error.WriteLine($"Aplikasi mengalami kesalahan: {ex.Message}");
                System.Console.Error.WriteLine("Silakan coba jalankan aplikasi kembali atau hubungi dukungan teknis.");
            }
        }
        
        // Check if running in Replit environment
        private static bool IsReplitEnvironment()
        {
            try
            {
                return System.Environment.GetEnvironmentVariable("REPL_ID") != null ||
                       System.Environment.GetEnvironmentVariable("REPL_OWNER") != null;
            }
            catch
            {
                return false;
            }
        }
        
        // Check if running on Windows
        private static bool IsWindowsEnvironment()
        {
            try
            {
                return System.Environment.OSVersion.Platform == PlatformID.Win32NT;
            }
            catch
            {
                return false;
            }
        }
        
        // Check if required DLLs are present in the application directory
        private static bool AreRequiredDllsPresent()
        {
            try
            {
                string[] requiredDlls = new[]
                {
                    "av_libglesv2.dll",
                    "e_sqlite3.dll",
                    "libHarfBuzzSharp.dll",
                    "libSkiaSharp.dll"
                };
                
                string appDirectory = AppDomain.CurrentDomain.BaseDirectory;
                
                return requiredDlls.All(dll => File.Exists(Path.Combine(appDirectory, dll)));
            }
            catch
            {
                // If we can't check, assume they're present
                return true;
            }
        }
        
        // Check if we have write access to the application folder
        private static bool HasWriteAccessToAppFolder()
        {
            try
            {
                string appDirectory = AppDomain.CurrentDomain.BaseDirectory;
                string testFile = Path.Combine(appDirectory, $"write_test_{Guid.NewGuid()}.tmp");
                
                // Try to create a test file
                File.WriteAllText(testFile, "test");
                
                // If we got here, we have write access
                try
                {
                    File.Delete(testFile);
                }
                catch
                {
                    // Ignore cleanup errors
                }
                
                return true;
            }
            catch
            {
                return false;
            }
        }
        
        // Ensure all necessary data directories exist
        private static void EnsureDataDirectoriesExist()
        {
            try
            {
                // Create application data folder
                string appDataPath = Path.Combine(
                    System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),
                    "AluGlassEstimator"
                );
                
                // Create necessary subdirectories
                string[] folders = new[] {
                    "Data",     // For database files
                    "Exports",  // For exported reports
                    "Logs",     // For error logs
                    "Backup",   // For data backups
                    "Temp"      // For temporary files
                };
                
                Directory.CreateDirectory(appDataPath);
                
                foreach (string folder in folders)
                {
                    Directory.CreateDirectory(Path.Combine(appDataPath, folder));
                }
            }
            catch
            {
                // Ignore errors, we'll create folders as needed
            }
        }
        
        // Show an error message dialog (for Windows)
        private static void ShowErrorMessage(string message)
        {
            try
            {
                if (IsWindowsEnvironment())
                {
                    // Try to show a Windows message box
                    Process process = new Process();
                    process.StartInfo.FileName = "cmd.exe";
                    process.StartInfo.Arguments = $"/c mshta \"javascript:alert('{message.Replace("'", "\\'")}');window.close();\"";
                    process.StartInfo.CreateNoWindow = true;
                    process.StartInfo.UseShellExecute = false;
                    process.Start();
                    
                    // Wait a bit for the dialog to show
                    Thread.Sleep(100);
                }
            }
            catch
            {
                // Ignore errors, we'll fallback to console messages
            }
        }

        // Avalonia configuration, don't remove; also used by visual designer.
        public static AppBuilder BuildAvaloniaApp()
            => AppBuilder.Configure<App>()
                .UsePlatformDetect()
                .LogToTrace();
    }
}
