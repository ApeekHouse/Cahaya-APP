Aplikasi AluGlass Estimator harus dijalankan di Windows. Silakan unduh file AluGlassEstimator_v2.zip dari Replit dan ekstrak di komputer Windows Anda.
